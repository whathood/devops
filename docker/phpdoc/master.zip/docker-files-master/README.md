#Docker-files:

- bower
- cloud9
- faye-app
- packagist
- php5-cli
- php5-fpm
- sencha-cmd