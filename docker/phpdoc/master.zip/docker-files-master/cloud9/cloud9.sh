#!/bin/bash

node /cloud9/server.js $@

sleep 0.5
