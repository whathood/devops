#!/bin/bash

. /.cravler/php5-cli-config.sh

exec $@