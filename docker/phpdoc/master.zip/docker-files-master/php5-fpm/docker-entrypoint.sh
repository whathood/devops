#!/bin/bash

. /.cravler/php5-cli-config.sh
. /.cravler/php5-fpm-config.sh

exec $@